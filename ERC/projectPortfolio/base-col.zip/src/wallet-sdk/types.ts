
export type Chain = {
  id: number;
  name: string;
  rpcUrl: string;
  currency: {
    name: string;
    symbol: string;
    decimals: number;
  },
  blockExplorer: {
    name: string;
    url: string;
  }
};

export interface WalletStatus {
  address?: string;
  chainId?: number;
  isConnecting: boolean;
  isConnected: boolean;
  ensName?: string;
  error: string | null;
  chains: Chain[];
  provider: any;
}


export interface WalletContextValue extends WalletStatus {
  connect: (walledID: string) => Promise<void>;
  disconnect: () => Promise<void>;
  switchChain: (chainId: number) => Promise<void>;
  openModal: () => void;
  closeModal: () => void;
}
